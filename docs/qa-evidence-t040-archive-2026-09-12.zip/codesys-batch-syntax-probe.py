# -*- coding: utf-8 -*-
import json
import os
import sys
import traceback

request_path = "C:\\temp\\request.json"
result_path = "C:\\temp\\result.json"

def read_json(path_value):
    handle = open(path_value, 'rb')
    try:
        return json.loads(handle.read().decode('utf-8'))
    finally:
        handle.close()

def write_json(value):
    parent = os.path.dirname(result_path)
    if parent and not os.path.isdir(parent): os.makedirs(parent)
    handle = open(result_path, 'wb')
    try:
        handle.write(json.dumps(value, sort_keys=True, ensure_ascii=False).encode('utf-8'))
    finally:
        handle.close()

def value_or(obj, name, default=None):
    try: return getattr(obj, name)
    except: return default

def object_name(obj):
    try: return obj.get_name()
    except: return str(value_or(obj, 'name', ''))

def object_row(obj):
    row = {
        'name': object_name(obj),
        'type': str(value_or(obj, 'type', '')),
        'guid': str(value_or(obj, 'guid', '')),
        'isFolder': bool(value_or(obj, 'is_folder', False)),
        'hasDeclaration': bool(value_or(obj, 'has_textual_declaration', False)),
        'hasImplementation': bool(value_or(obj, 'has_textual_implementation', False)),
        'isApplication': bool(value_or(obj, 'is_application', False)),
        'hasLibraryManager': bool(value_or(obj, 'has_library_manager', False))
    }
    try:
        if row['hasDeclaration'] or hasattr(obj, 'textual_declaration'):
            row['declaration'] = obj.textual_declaration.text
    except: pass
    try:
        if row['hasImplementation'] or hasattr(obj, 'textual_implementation'):
            row['implementation'] = obj.textual_implementation.text
    except: pass
    try:
        manager = obj.get_library_manager()
        refs = []
        for ref in manager.references:
            refs.append({'name': str(value_or(ref, 'name', '')), 'namespace': str(value_or(ref, 'namespace', '')), 'id': str(value_or(ref, 'id', ''))})
        row['libraries'] = refs[:500]
    except: pass
    return row

def find_one(project, name, guid='', require_text=False):
    matches = project.find(name, True) or []
    if guid:
        wanted_guid = str(guid).lower()
        matches = [obj for obj in matches if str(value_or(obj, 'guid', '')).lower() == wanted_guid]
    if require_text:
        matches = [obj for obj in matches if bool(value_or(obj, 'has_textual_declaration', False)) or bool(value_or(obj, 'has_textual_implementation', False))]
    if len(matches) == 0: raise Exception('Object not found: ' + name)
    if len(matches) > 1: raise Exception('Object name is ambiguous; provide objectGuid: ' + name)
    return matches[0]

class TaskHiveExportReporter(ExportReporter):
    def __init__(self): self.messages = []
    def error(self, obj, message): self.messages.append({'level':'error','object':object_name(obj),'message':str(message)})
    def warning(self, obj, message): self.messages.append({'level':'warning','object':object_name(obj),'message':str(message)})
    def nonexportable(self, obj): self.messages.append({'level':'skipped','object':object_name(obj),'message':'nonexportable'})
    @property
    def aborting(self): return False

class TaskHiveImportReporter(ImportReporter):
    def __init__(self): self.messages = []
    def error(self, message): self.messages.append({'level':'error','message':str(message)})
    def warning(self, message): self.messages.append({'level':'warning','message':str(message)})
    def added(self, obj): self.messages.append({'level':'added','object':object_name(obj)})
    def replaced(self, obj): self.messages.append({'level':'replaced','object':object_name(obj)})
    def skipped(self, objectname): self.messages.append({'level':'skipped','object':str(objectname)})
    def resolve_conflict(self, obj): return ConflictResolve.Replace
    @property
    def aborting(self): return False

request = read_json(request_path)
action = request['action']
project_path = request.get('projectPath', '')
project = None
result = {'ok': True, 'action': action, 'safetyMode': 'isolated-offline-project-only', 'projectPath': project_path, 'reporterGlobals': sorted([str(key) for key in globals().keys() if 'Reporter' in str(key) or 'Conflict' in str(key)])}
try:
    if action == 'create-project':
        project = projects.create(project_path, True)
        project.save()
        result['created'] = True
    else:
        project = projects.open(project_path)
        if action == 'inspect-project':
            objects = project.get_children(True)
            active_application = value_or(project, 'active_application', None)
            result['project'] = {'path': str(project.path), 'dirty': bool(project.dirty), 'activeApplication': object_name(active_application) if active_application else ''}
            result['objects'] = [object_row(obj) for obj in objects]
            result['objectCount'] = len(objects)
            result['complete'] = True
            result['textTruncated'] = False
        elif action in ['create-pou', 'create-gvl', 'create-dut']:
            parent_name = request.get('parentName', '')
            container = find_one(project, parent_name) if parent_name else value_or(project, 'active_application', None)
            if container is None: raise Exception('No active application/container; provide parentName')
            if action == 'create-pou':
                pou_types = {'program': PouType.Program, 'function-block': PouType.FunctionBlock, 'function': PouType.Function}
                created = container.create_pou(request['objectName'], pou_types[request.get('pouType', 'program')], ImplementationLanguages.st)
            elif action == 'create-gvl': created = container.create_gvl(request['objectName'])
            else: created = container.create_dut(request['objectName'], DutType.Structure)
            if request.get('declaration') is not None and hasattr(created, 'textual_declaration'): created.textual_declaration.replace(request.get('declaration', ''))
            if request.get('implementation') is not None and hasattr(created, 'textual_implementation'): created.textual_implementation.replace(request.get('implementation', ''))
            project.save()
            result['createdObject'] = object_row(created)
        elif action == 'update-text':
            target = find_one(project, request['objectName'], request.get('objectGuid', ''), True)
            if request.get('declaration') is not None: target.textual_declaration.replace(request.get('declaration', ''))
            if request.get('implementation') is not None: target.textual_implementation.replace(request.get('implementation', ''))
            project.save()
            result['updatedObject'] = object_row(target)
        elif action == 'apply-changes':
            # Batch all confirmed object edits in one ScriptEngine process and
            # one project.save().  The previous UI loop spawned CODESYS once
            # per object, which made multi-object writes needlessly serial.
            applied = []
            for change in request.get('changes', []):
                operation = str(change.get('operation', 'update-text'))
                if operation in ['create-pou', 'create-gvl', 'create-dut']:
                    parent_name = change.get('parentName', '')
                    container = find_one(project, parent_name) if parent_name else value_or(project, 'active_application', None)
                    if container is None: raise Exception('No active application/container; provide parentName')
                    if operation == 'create-pou':
                        pou_types = {'program': PouType.Program, 'function-block': PouType.FunctionBlock, 'function': PouType.Function}
                        created = container.create_pou(change['objectName'], pou_types.get(change.get('pouType', 'program'), PouType.Program), ImplementationLanguages.st)
                    elif operation == 'create-gvl': created = container.create_gvl(change['objectName'])
                    else: created = container.create_dut(change['objectName'], DutType.Structure)
                    if change.get('declaration') is not None and hasattr(created, 'textual_declaration'): created.textual_declaration.replace(change.get('declaration', ''))
                    if change.get('implementation') is not None and hasattr(created, 'textual_implementation'): created.textual_implementation.replace(change.get('implementation', ''))
                    applied.append({'operation': operation, 'object': object_row(created)})
                elif operation == 'update-text':
                    target = find_one(project, change['objectName'], change.get('objectGuid', ''), True)
                    if change.get('declaration') is not None: target.textual_declaration.replace(change.get('declaration', ''))
                    if change.get('implementation') is not None: target.textual_implementation.replace(change.get('implementation', ''))
                    applied.append({'operation': operation, 'object': object_row(target)})
                else:
                    raise Exception('Unsupported batch operation: ' + operation)
            project.save()
            result['applied'] = applied
            result['changeCount'] = len(applied)
        elif action == 'export-xml':
            target_name = request.get('objectName', '')
            target = find_one(project, target_name) if target_name else project
            reporter = TaskHiveExportReporter()
            target.export_xml(reporter, request['xmlPath'], True)
            result['xmlPath'] = request['xmlPath']
            result['messages'] = reporter.messages
        elif action == 'import-xml':
            reporter = TaskHiveImportReporter()
            project.import_xml(reporter, request['xmlPath'])
            project.save()
            result['xmlPath'] = request['xmlPath']
            result['messages'] = reporter.messages
        elif action == 'build' or action == 'rebuild':
            application = value_or(project, 'active_application', None)
            if application is None: raise Exception('Project has no active application')
            if action == 'build': application.build()
            else: application.rebuild()
            messages = []
            try:
                for item in system.get_message_objects():
                    messages.append({'severity':str(value_or(item,'severity','')),'text':str(value_or(item,'text',item))})
            except: pass
            result['messages'] = messages[-1000:]
            result['errorCount'] = len([item for item in messages if 'error' in item.get('severity','').lower()])
finally:
    if project is not None:
        try: project.close()
        except: pass
write_json(result)
